<?php
require "BD.php";

function retorno($retorno){
	header('Content-type: application/json');
	echo(json_encode($retorno));	
}

function autenticar($usuario, $senha){	
	$con = conectar();
	$qr = 'SELECT * from usuarios where usuario = "'.$usuario.'" AND senha = "'.$senha.'"';
	$usr = $con->query($qr)->fetch();

	if($usr){ 	echo(1); }
	else {echo(0);}
}


function adicionar($nome, $habilidades, $foto, $usuario){
	$con = conectar();
	$habilidades = explode(",", $habilidades);
	array_pop($habilidades);
	if($user = $con->query('INSERT INTO mutantes(nome, foto, usuario) VALUES ("'.$nome.'","'.$foto.'","'.$usuario.'")')){
	foreach($habilidades as $habilidade){
		$con->query('INSERT INTO poderes(nome, mutante) VALUES ("'.$habilidade.'","'.$nome.'")');			
	}
	echo(1);
	}
	else{
		echo(0);
	}
}

function remover($nome){
	$con = conectar();
	$user = $con->query('DELETE FROM mutantes WHERE nome = "'.$nome.'"');	
}

function atualizar($nome, $anterior, $habilidades, $foto, $usuario){
	remover($anterior);
	adicionar($nome, $habilidades, $foto, $usuario);
}

function listar(){
	$con = conectar();
	foreach($con->query('SELECT * from mutantes') as $mutante){
		echo($mutante['nome'].' ; '.$mutante['foto']."\n~");
	}
}

function pegaMutante($nome){
	$con = conectar();
	foreach($con->query('SELECT nome from mutantes where nome like "%'.$nome.'%"') as $nome){
		echo($nome['nome']."\n");
	}
}
function pegaMutantesPorPoder($poder){
	$con = conectar();
	foreach($con->query('SELECT mutante from Poderes where nome like"%'.$poder.'%"') as $poder){
		echo($poder['mutante']."\n");
	}
}

function pegaPoderes($nome){
	$con = conectar();
	foreach($con->query('SELECT nome from Poderes where mutante ="'.$nome.'"') as $poder){
		echo($poder['nome']."\n");
	}
}
	
?>