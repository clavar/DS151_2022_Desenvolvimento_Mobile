<?php
require "OpBD.php";

if($_SERVER['REQUEST_METHOD'] == "GET"){

	$op = htmlspecialchars($_GET["operacao"]);

	if($op == "autenticar"){autenticar($_GET["usuario"], $_GET["senha"]);}
	if($op == "adicionarLogin"){ adicionarLogin($_GET["usuario"], $_GET["senha"]);}
	if($op == "removerLogin"){ removerLogin($_GET["usuario"]);}	
	if($op == "adicionar"){ adicionar($_GET["nome"], $_GET["habilidades"], $_GET["foto"], $_GET["usuario"]);}
	if($op == "remover"){ remover($_GET["nome"]);}
	if($op == "atualizar"){ atualizar($_GET["nome"], $_GET["anterior"],$_GET["habilidades"], $_GET["foto"], $_GET['usuario']);}
	if($op == "listar"){ listar();}
	if($op == "pegaMutantesPorPoder"){ pegaMutantesPorPoder($_GET["chave"]);}
	if($op == "pegaMutante"){ pegaMutante($_GET["chave"]);}
	if($op == "pegaPoderes"){ pegaPoderes($_GET["nome"]);}

}
if($_SERVER['REQUEST_METHOD'] == "POST"){
	$op = htmlspecialchars($_POST["operacao"]);
		if($op == "adicionar"){ adicionar($_POST["nome"], $_POST["habilidades"], $_POST["foto"], $_POST["usuario"]);}
}

?>
