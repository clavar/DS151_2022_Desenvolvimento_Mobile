<?php

function conectar(){
	$host="localhost";
	$db="MutantesWS";
	$usuario="root";
	$senha="";

	try{
		$pdo = new PDO("mysql:host=".$host.";dbname=".$db, $usuario,$senha); 
		return $pdo;		
	}catch(PDOException $e){
		echo($e);
		die();
	}
}

?>
